import { makeStyles } from "@material-ui/core/styles";

const useStyles = makeStyles(theme => ({
  root: {
    width: "100%",
    "& > * + *": {
      marginTop: theme.spacing(2)
    }
  },
  title: {
    paddingLeft: "10px"
  },
  maxBarPaid: {
    fontSize: "10px",
    opacity: 0.8,
    color: "grey"
  }
}));

export default useStyles;
