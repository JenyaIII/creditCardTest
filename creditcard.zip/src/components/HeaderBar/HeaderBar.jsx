import React, { useEffect, useState } from "react";
import Grid from "@material-ui/core/Grid";
import Typography from "@material-ui/core/Typography";
import LinearProgress from "@material-ui/core/LinearProgress";
import IconButton from "@material-ui/core/IconButton";
import MoreHorizIcon from "@material-ui/icons/MoreHoriz";
import useStyles from "./Styles";

const HeaderBar = ({ cardName, barPaid, barMax }) => {
  const classes = useStyles();
  const paidProgress = barPaid.toLocaleString();
  const maxPaidProgress = barMax.toLocaleString();
  const [completed, setCompleted] = useState(0);

  useEffect(() => {
    setCompleted((barPaid * 100) / barMax);
  }, [completed]);

  return (
    <Grid container direction="row" justify="center" alignItems="center">
      <Grid item xs={3}>
        <Typography gutterBottom variant="subtitle1" className={classes.title}>
          {cardName}
        </Typography>
      </Grid>
      <Grid item xs={8}>
        <LinearProgress variant="determinate" value={completed} />
        <Grid container>
          <Grid item xs={10}>
            <Typography color="primary" variant="body2">
              ${paidProgress}
            </Typography>
          </Grid>
          <Grid item xs={2}>
            <Typography className={classes.maxBarPaid} variant="caption">
              Paid of ${maxPaidProgress}
            </Typography>
          </Grid>
        </Grid>
      </Grid>
      <Grid container item xs={1} justify="center" alignItems="center">
        <IconButton aria-label="menu">
          <MoreHorizIcon />
        </IconButton>
      </Grid>
    </Grid>
  );
};

export default HeaderBar;
