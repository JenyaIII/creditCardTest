import React from "react";
import { Typography, Grid, Chip, Button } from "@material-ui/core";
import useStyles from "./Styles";

const PaymentsInfo = ({ paymentMade, nextPaymentDate }) => {
  const classes = useStyles();
  const date = new Date(nextPaymentDate);
  console.log("KEK", date.toDateString().slice(3));

  return (
    <>
      <Grid item xs={2}>
        <Typography className={classes.interest}>Next Payment</Typography>
        {paymentMade ? (
          <Chip size="small" label="Paid" className={classes.chipPaid} />
        ) : (
          <Chip size="small" label="Unpaid" color="secondary" />
        )}
      </Grid>
      <Grid item>
        <Typography className={classes.cardInfoPayment}>
          {date.toDateString().slice(3)}
        </Typography>
        <Button variant="contained" color="primary">
          Make Payment
        </Button>
      </Grid>
    </>
  );
};

export default PaymentsInfo;
