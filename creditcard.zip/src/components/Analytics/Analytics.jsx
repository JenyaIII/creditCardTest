import React from "react";
import { Typography, Grid } from "@material-ui/core";
import useStyles from "./Styles";

const Analytics = ({ interest, interestPaid, principal }) => {
  const classes = useStyles();

  return (
    <>
      <Grid item xs={1}>
        <Typography className={classes.interest}>Interest</Typography>
        <Typography className={classes.cardInfo}>
          Interest: ${interestPaid}
        </Typography>
      </Grid>
      <Grid item xs={1}>
        <Typography className={classes.cardInfoPayment}>{interest}%</Typography>
        <Typography className={classes.principal}>
          Principal: ${principal}
        </Typography>
      </Grid>
    </>
  );
};

export default Analytics;
