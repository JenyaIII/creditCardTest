import React from "react";
import { Typography, Grid } from "@material-ui/core";
import useStyles from "./Styles";

const CardInfo = ({ cardImage, balance, nextPayment, lastPayment }) => {
  const classes = useStyles();
  const paymentBalance = balance.toLocaleString();

  return (
    <>
      <Grid item xs={3}>
        <img className={classes.img} alt="complex" src={cardImage} />
      </Grid>
      <Grid item xs={1}>
        <Typography className={classes.cardInfo}>Balance</Typography>
        <Typography className={classes.cardInfo}>Next Payment</Typography>
        <Typography className={classes.cardInfo}>Last Payment</Typography>
      </Grid>
      <Grid item xs={1}>
        <Typography className={classes.cardInfoPayment}>
          ${paymentBalance}
        </Typography>
        <Typography className={classes.cardInfoPayment}>
          ${nextPayment}
        </Typography>
        <Typography className={classes.cardInfoPayment}>
          ${lastPayment}
        </Typography>
      </Grid>
    </>
  );
};

export default CardInfo;
