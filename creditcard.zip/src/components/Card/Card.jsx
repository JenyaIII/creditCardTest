import React, { useContext } from "react";
import Grid from "@material-ui/core/Grid";
import Paper from "@material-ui/core/Paper";
import { CardContext } from "../../context/CardContext";
import useStyles from "./Styles";
import HeaderBar from "../HeaderBar/HeaderBar";
import CardInfo from "../CardInfo/CardInfo";
import Analytics from "../Analytics/Analytics";
import PaymentsInfo from "../PaymentsInfo/PaymentsInfo";

export default function ComplexGrid() {
  const classes = useStyles();
  const { cardData } = useContext(CardContext);
  console.log("CAARDS", cardData);

  return (
    <>
      {cardData.map(item => (
        <Paper className={classes.paper} key={item.balance}>
          <Grid container spacing={2}>
            <HeaderBar
              cardName={item.cardName}
              barMax={item.barMax}
              barPaid={item.barPaid}
            />
            <Grid
              container
              direction="row"
              justify="flex-start"
              alignItems="center"
              alignContent="space-around"
            >
              <CardInfo
                balance={item.balance}
                nextPayment={item.nextPayment}
                lastPayment={item.lastPayment}
                cardImage={item.cardImage}
              />
              <Analytics
                interest={item.interest.apr}
                interestPaid={item.interest.interestPaid}
                principal={item.interest.principal}
              />
              <PaymentsInfo
                paymentMade={item.paymentMade}
                nextPaymentDate={item.nextPaymentDate}
              />
            </Grid>
          </Grid>
        </Paper>
      ))}
    </>
  );
}
