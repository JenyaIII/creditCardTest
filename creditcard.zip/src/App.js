import React from "react";
import "./App.css";

import CardContextProvider from "./context/CardContext.js";
import Card from "./components/Card/Card.jsx";

function App() {
  return (
    <CardContextProvider>
      <div className="App">
        <Card />
      </div>
    </CardContextProvider>
  );
}

export default App;
